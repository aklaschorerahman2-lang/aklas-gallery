package com.aklas.gallery.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF09090B)
val ObsidianSurface = Color(0xFF121215)
val ObsidianSurfaceElevated = Color(0xFF1A1A1F)
val ObsidianBorder = Color(0xFF27272A)
val TextPrimary = Color(0xFFF4F4F5)
val TextSecondary = Color(0xFFA1A1AA)
val AmberAccent = Color(0xFFE4A853)
val AmberOnAccent = Color(0xFF18120B)
val DangerRed = Color(0xFFEF4444)
val EmeraldSafe = Color(0xFF10B981)
