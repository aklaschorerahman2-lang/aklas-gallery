package com.aklas.gallery.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class MediaType {
    IMAGE,
    VIDEO
}

@Serializable
data class MediaItem(
    val id: String,
    val uriString: String,
    val displayName: String,
    val mimeType: String,
    val type: MediaType,
    val sizeBytes: Long,
    val width: Int = 0,
    val height: Int = 0,
    val durationMs: Long = 0L,
    val dateAddedMs: Long = System.currentTimeMillis(),
    val albumIds: List<String> = emptyList(),
    val isFavorite: Boolean = false
)

@Serializable
data class Album(
    val id: String,
    val name: String,
    val createdAtMs: Long = System.currentTimeMillis()
)

@Serializable
data class GalleryStore(
    val items: List<MediaItem> = emptyList(),
    val albums: List<Album> = emptyList()
)

@Serializable
data class VaultEntry(
    val id: String,
    val originalName: String,
    val mimeType: String,
    val type: MediaType,
    val originalSizeBytes: Long,
    val encryptedFileName: String,
    val thumbnailFileName: String? = null,
    val durationMs: Long = 0L,
    val importedAtMs: Long = System.currentTimeMillis()
)

@Serializable
data class VaultIndex(
    val entries: List<VaultEntry> = emptyList()
)

enum class AutoLockTimeout(val label: String, val durationMs: Long) {
    IMMEDIATE("Immediate on background", 0L),
    THIRTY_SECONDS("30 seconds", 30_000L),
    ONE_MINUTE("1 minute", 60_000L),
    FIVE_MINUTES("5 minutes", 300_000L)
}
