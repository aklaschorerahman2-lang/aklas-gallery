package com.aklas.gallery

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

class VaultCipherTest {
    @Test
    fun aes256Gcm_roundTripAndTamperDetection() {
        val keyGen = KeyGenerator.getInstance("AES").apply { init(256) }
        val secretKey = keyGen.generateKey()

        val plaintext = "Aklas Gallery secret photo payload".encodeToByteArray()
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }

        val encryptCipher = Cipher.getInstance("AES/GCM/NoPadding")
        encryptCipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
        val ciphertext = encryptCipher.doFinal(plaintext)

        val decryptCipher = Cipher.getInstance("AES/GCM/NoPadding")
        decryptCipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
        assertArrayEquals(plaintext, decryptCipher.doFinal(ciphertext))

        // Flip a bit in ciphertext and verify GCM auth tag fails
        val tampered = ciphertext.copyOf()
        tampered[0] = (tampered[0].toInt() xor 0x01).toByte()
        val tamperedCipher = Cipher.getInstance("AES/GCM/NoPadding")
        tamperedCipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
        assertThrows(AEADBadTagException::class.java) {
            tamperedCipher.doFinal(tampered)
        }
    }
}
