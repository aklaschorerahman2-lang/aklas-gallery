package com.aklas.gallery.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CollectionsBookmark
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aklas.gallery.ui.theme.AmberAccent
import com.aklas.gallery.ui.theme.ObsidianBg
import com.aklas.gallery.ui.theme.ObsidianSurface
import com.aklas.gallery.ui.theme.ObsidianSurfaceElevated
import com.aklas.gallery.ui.theme.TextSecondary
import com.aklas.gallery.ui.viewmodel.GalleryViewModel

enum class AklasTab(val label: String) {
    PHOTOS("Photos"),
    ALBUMS("Albums"),
    SEARCH("Search"),
    VAULT("Vault")
}

@Composable
fun AklasAppScaffold(viewModel: GalleryViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var activeTab by remember { mutableStateOf(AklasTab.PHOTOS) }
    var selectedMediaId by remember { mutableStateOf<String?>(null) }
    val selectedMediaPreview = state.store.items.firstOrNull { it.id == selectedMediaId }
    val snackbarHostState = remember { SnackbarHostState() }

    val galleryPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris ->
        viewModel.importMediaFromPicker(uris)
    }

    val vaultPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 25)
    ) { uris ->
        viewModel.importDirectToVault(uris)
    }

    LaunchedEffect(state.statusBanner) {
        val message = state.statusBanner ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        viewModel.clearStatusBanner()
    }

    Scaffold(
        containerColor = ObsidianBg,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (selectedMediaPreview == null && state.activeDecryptedPreview == null) {
                NavigationBar(containerColor = ObsidianSurface) {
                    val items = listOf(
                        AklasTab.PHOTOS to Icons.Outlined.PhotoLibrary,
                        AklasTab.ALBUMS to Icons.Outlined.CollectionsBookmark,
                        AklasTab.SEARCH to Icons.Outlined.Search,
                        AklasTab.VAULT to Icons.Outlined.Lock
                    )
                    items.forEach { (tab, icon) ->
                        val selected = activeTab == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { activeTab = tab },
                            icon = { Icon(imageVector = icon, contentDescription = tab.label) },
                            label = { Text(tab.label, style = MaterialTheme.typography.labelMedium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AmberAccent,
                                selectedTextColor = AmberAccent,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = ObsidianSurfaceElevated
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = activeTab, label = "tab_crossfade") { tab ->
                when (tab) {
                    AklasTab.PHOTOS -> PhotosScreen(
                        state = state,
                        items = viewModel.filteredItems(),
                        onFilterSelected = viewModel::setFilter,
                        onImportClick = {
                            galleryPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                        onToggleFavorite = viewModel::toggleFavorite,
                        onMediaClick = { selectedMediaId = it.id }
                    )

                    AklasTab.ALBUMS -> AlbumsScreen(
                        state = state,
                        onCreateAlbum = viewModel::createAlbum,
                        onMediaClick = { selectedMediaId = it.id },
                        onToggleFavorite = viewModel::toggleFavorite
                    )

                    AklasTab.SEARCH -> SearchScreen(
                        query = state.searchQuery,
                        onQueryChange = viewModel::setSearchQuery,
                        items = viewModel.filteredItems(),
                        onMediaClick = { selectedMediaId = it.id }
                    )

                    AklasTab.VAULT -> {
                        if (!state.isVaultUnlocked) {
                            VaultPinScreen(
                                mode = state.pinMode,
                                errorMessage = state.pinErrorMessage,
                                lockoutRemainingSeconds = state.lockoutRemainingSeconds,
                                onPinSubmitted = viewModel::submitVaultPin
                            )
                        } else {
                            VaultScreen(
                                state = state,
                                onImportToVault = {
                                    vaultPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                                    )
                                },
                                onOpenEntry = viewModel::openVaultEntryPreview,
                                onDeleteEntry = viewModel::deleteVaultEntry,
                                onLockNow = viewModel::lockVault,
                                onChangePin = viewModel::startChangePin,
                                onAutoLockTimeoutSelected = viewModel::setAutoLockTimeout,
                                onInteraction = viewModel::registerVaultInteraction
                            )
                        }
                    }
                }
            }
        }
    }

    selectedMediaPreview?.let { item ->
        MediaPreviewScreen(
            item = item,
            albums = state.store.albums,
            onDismiss = { selectedMediaId = null },
            onToggleFavorite = { viewModel.toggleFavorite(item.id) },
            onToggleAlbum = { albumId -> viewModel.toggleItemInAlbum(item.id, albumId) },
            onMoveToVault = {
                viewModel.moveGalleryItemToVault(item)
                selectedMediaId = null
            },
            onRemoveFromGallery = {
                viewModel.removeFromGallery(item.id)
                selectedMediaId = null
            }
        )
    }

    state.activeDecryptedPreview?.let { (entry, file) ->
        DecryptedVaultPreviewScreen(
            entry = entry,
            decryptedFile = file,
            onDismiss = viewModel::closeVaultEntryPreview,
            onDelete = { viewModel.deleteVaultEntry(entry) }
        )
    }
}
