package com.aklas.gallery.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.aklas.gallery.data.model.MediaItem
import com.aklas.gallery.data.model.MediaType
import com.aklas.gallery.ui.theme.AmberAccent
import com.aklas.gallery.ui.theme.AmberOnAccent
import com.aklas.gallery.ui.theme.ObsidianBorder
import com.aklas.gallery.ui.theme.ObsidianSurface
import com.aklas.gallery.ui.theme.ObsidianSurfaceElevated
import com.aklas.gallery.ui.theme.TextPrimary
import com.aklas.gallery.ui.theme.TextSecondary
import com.aklas.gallery.ui.viewmodel.GalleryUiState

private data class AlbumCardModel(
    val id: String,
    val title: String,
    val items: List<MediaItem>
)

@Composable
fun AlbumsScreen(
    state: GalleryUiState,
    onCreateAlbum: (String) -> Unit,
    onMediaClick: (MediaItem) -> Unit,
    onToggleFavorite: (String) -> Unit
) {
    var selectedAlbumId by remember { mutableStateOf<String?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newAlbumName by remember { mutableStateOf("") }

    val allAlbums = remember(state.store) {
        val smart = listOf(
            AlbumCardModel("smart_favorites", "Favorites", state.store.items.filter { it.isFavorite }),
            AlbumCardModel("smart_videos", "Videos", state.store.items.filter { it.type == MediaType.VIDEO })
        )
        val user = state.store.albums.map { album ->
            AlbumCardModel(
                id = album.id,
                title = album.name,
                items = state.store.items.filter { album.id in it.albumIds }
            )
        }
        smart + user
    }

    val openedAlbum = allAlbums.firstOrNull { it.id == selectedAlbumId }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (openedAlbum != null) {
                    IconButton(onClick = { selectedAlbumId = null }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                            contentDescription = "Back to albums",
                            tint = TextPrimary
                        )
                    }
                }
                Text(
                    text = openedAlbum?.title ?: "Albums",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
            }
            if (openedAlbum == null) {
                Button(
                    onClick = { showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ObsidianSurfaceElevated,
                        contentColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Outlined.CreateNewFolder, contentDescription = null)
                    Spacer(Modifier.padding(start = 6.dp))
                    Text("New Album")
                }
            }
        }

        if (openedAlbum != null) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 116.dp),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(openedAlbum.items, key = { it.id }) { item ->
                    MediaGridTile(
                        item = item,
                        onClick = { onMediaClick(item) },
                        onToggleFavorite = { onToggleFavorite(item.id) }
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(allAlbums, key = { it.id }) { album ->
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(ObsidianSurface)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
                            .clickable { selectedAlbumId = album.id }
                            .padding(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1.1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ObsidianSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            val cover = album.items.firstOrNull()
                            if (cover != null) {
                                AsyncImage(
                                    model = Uri.parse(cover.uriString),
                                    contentDescription = album.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Text("Empty", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(album.title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        Text("${album.items.size} items", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = ObsidianSurface,
            title = { Text("Create Album", color = TextPrimary) },
            text = {
                OutlinedTextField(
                    value = newAlbumName,
                    onValueChange = { newAlbumName = it },
                    label = { Text("Album name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateAlbum(newAlbumName)
                        newAlbumName = ""
                        showCreateDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberAccent, contentColor = AmberOnAccent)
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }
}
