package com.aklas.gallery

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aklas.gallery.ui.screens.AklasAppScaffold
import com.aklas.gallery.ui.theme.AklasGalleryTheme
import com.aklas.gallery.ui.viewmodel.GalleryViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: GalleryViewModel by viewModels {
        GalleryViewModel.factory(application as AklasGalleryApp)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            // Prevent screenshots and recents thumbnails whenever Secret Vault is unlocked
            LaunchedEffect(state.isVaultUnlocked) {
                if (state.isVaultUnlocked) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            AklasGalleryTheme {
                AklasAppScaffold(viewModel = viewModel)
            }
        }
    }
}
