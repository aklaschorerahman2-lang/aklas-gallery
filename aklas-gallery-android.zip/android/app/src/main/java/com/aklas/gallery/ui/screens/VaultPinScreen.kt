package com.aklas.gallery.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aklas.gallery.ui.theme.AmberAccent
import com.aklas.gallery.ui.theme.AmberOnAccent
import com.aklas.gallery.ui.theme.DangerRed
import com.aklas.gallery.ui.theme.ObsidianBorder
import com.aklas.gallery.ui.theme.ObsidianSurface
import com.aklas.gallery.ui.theme.ObsidianSurfaceElevated
import com.aklas.gallery.ui.theme.TextPrimary
import com.aklas.gallery.ui.theme.TextSecondary
import com.aklas.gallery.ui.viewmodel.VaultPinMode

@Composable
fun VaultPinScreen(
    mode: VaultPinMode,
    errorMessage: String?,
    lockoutRemainingSeconds: Int,
    onPinSubmitted: (String) -> Unit
) {
    var pinBuffer by remember(mode) { mutableStateOf("") }
    val haptics = LocalHapticFeedback.current
    val isLockedOut = lockoutRemainingSeconds > 0

    val title = when (mode) {
        VaultPinMode.SETUP_FIRST -> "Create Vault PIN"
        VaultPinMode.SETUP_CONFIRM -> "Confirm Vault PIN"
        VaultPinMode.CHANGE_VERIFY_OLD -> "Verify Current PIN"
        VaultPinMode.LOCKED -> "Secret Vault Locked"
    }

    val subtitle = when (mode) {
        VaultPinMode.SETUP_FIRST -> "Choose a 4 to 6 digit PIN to guard your encrypted media"
        VaultPinMode.SETUP_CONFIRM -> "Re-enter your PIN to confirm"
        VaultPinMode.CHANGE_VERIFY_OLD -> "Enter your existing PIN before choosing a new one"
        VaultPinMode.LOCKED -> "Protected with Android Keystore AES-256-GCM"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(ObsidianSurfaceElevated)
                    .border(1.dp, ObsidianBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = AmberAccent)
            }
            Spacer(Modifier.height(16.dp))
            Text(title, style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(6) { index ->
                    val filled = index < pinBuffer.length
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(CircleShape)
                            .background(if (filled) AmberAccent else ObsidianSurfaceElevated)
                            .border(1.dp, if (filled) AmberAccent else ObsidianBorder, CircleShape)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            if (isLockedOut) {
                Text(
                    text = "Try again in ${lockoutRemainingSeconds}s",
                    style = MaterialTheme.typography.bodyMedium,
                    color = DangerRed
                )
            } else if (errorMessage != null) {
                Text(
                    text = errorMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = DangerRed
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val rows = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("DEL", "0", "OK")
            )
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    row.forEach { key ->
                        PinKeypadButton(
                            label = key,
                            enabled = !isLockedOut && (key != "OK" || pinBuffer.length >= 4),
                            isPrimary = key == "OK",
                            onClick = {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                when (key) {
                                    "DEL" -> if (pinBuffer.isNotEmpty()) pinBuffer = pinBuffer.dropLast(1)
                                    "OK" -> if (pinBuffer.length >= 4) {
                                        onPinSubmitted(pinBuffer)
                                        pinBuffer = ""
                                    }
                                    else -> if (pinBuffer.length < 6) {
                                        pinBuffer += key
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PinKeypadButton(
    label: String,
    enabled: Boolean,
    isPrimary: Boolean,
    onClick: () -> Unit
) {
    val bgColor = when {
        isPrimary && enabled -> AmberAccent
        else -> ObsidianSurface
    }
    val fgColor = when {
        isPrimary && enabled -> AmberOnAccent
        !enabled -> TextSecondary.copy(alpha = 0.4f)
        else -> TextPrimary
    }

    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(bgColor)
            .border(1.dp, ObsidianBorder, RoundedCornerShape(22.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        when (label) {
            "DEL" -> Icon(Icons.AutoMirrored.Outlined.Backspace, contentDescription = "Backspace", tint = fgColor)
            "OK" -> Icon(Icons.Outlined.Check, contentDescription = "Confirm PIN", tint = fgColor)
            else -> Text(label, style = MaterialTheme.typography.titleLarge, color = fgColor)
        }
    }
}
