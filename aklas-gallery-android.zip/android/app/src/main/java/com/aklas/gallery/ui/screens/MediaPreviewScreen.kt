package com.aklas.gallery.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.CollectionsBookmark
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.aklas.gallery.data.model.Album
import com.aklas.gallery.data.model.MediaItem
import com.aklas.gallery.data.model.MediaType
import com.aklas.gallery.data.model.VaultEntry
import com.aklas.gallery.ui.theme.AmberAccent
import com.aklas.gallery.ui.theme.DangerRed
import com.aklas.gallery.ui.theme.ObsidianBg
import com.aklas.gallery.ui.theme.ObsidianSurface
import com.aklas.gallery.ui.theme.TextPrimary
import com.aklas.gallery.ui.theme.TextSecondary
import java.io.File

@Composable
fun MediaPreviewScreen(
    item: MediaItem,
    albums: List<Album>,
    onDismiss: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleAlbum: (String) -> Unit,
    onMoveToVault: () -> Unit,
    onRemoveFromGallery: () -> Unit
) {
    var albumMenuOpen by remember { mutableStateOf(false) }

    Surface(color = Color.Black, modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (item.type == MediaType.VIDEO) {
                ExoVideoViewer(uri = Uri.parse(item.uriString))
            } else {
                ZoomableImageViewer(model = Uri.parse(item.uriString), contentDescription = item.displayName)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color.Black.copy(alpha = 0.65f))
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Column {
                        Text(item.displayName, color = TextPrimary, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                        Text(formatFileSize(item.sizeBytes), color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                    }
                }

                Row {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (item.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (item.isFavorite) AmberAccent else TextPrimary
                        )
                    }
                    Box {
                        IconButton(onClick = { albumMenuOpen = true }) {
                            Icon(Icons.Outlined.CollectionsBookmark, contentDescription = "Albums", tint = TextPrimary)
                        }
                        DropdownMenu(
                            expanded = albumMenuOpen,
                            onDismissRequest = { albumMenuOpen = false },
                            containerColor = ObsidianSurface
                        ) {
                            if (albums.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("Create an album in Albums tab", color = TextSecondary) },
                                    onClick = { albumMenuOpen = false }
                                )
                            } else {
                                albums.forEach { album ->
                                    val checked = album.id in item.albumIds
                                    DropdownMenuItem(
                                        text = { Text(album.name, color = TextPrimary) },
                                        trailingIcon = {
                                            Checkbox(checked = checked, onCheckedChange = null)
                                        },
                                        onClick = { onToggleAlbum(album.id) }
                                    )
                                }
                            }
                        }
                    }
                    IconButton(onClick = onMoveToVault) {
                        Icon(Icons.Outlined.Lock, contentDescription = "Encrypt into Vault", tint = AmberAccent)
                    }
                    IconButton(onClick = onRemoveFromGallery) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = "Remove", tint = DangerRed)
                    }
                }
            }
        }
    }
}

@Composable
fun DecryptedVaultPreviewScreen(
    entry: VaultEntry,
    decryptedFile: File,
    onDismiss: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(color = ObsidianBg, modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (entry.type == MediaType.VIDEO) {
                ExoVideoViewer(uri = Uri.fromFile(decryptedFile))
            } else {
                ZoomableImageViewer(model = decryptedFile, contentDescription = entry.originalName)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Close", tint = TextPrimary)
                    }
                    Column {
                        Text(entry.originalName, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                        Text("AES-256-GCM decrypted in temporary memory", color = AmberAccent, style = MaterialTheme.typography.labelMedium)
                    }
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "Wipe from Vault", tint = DangerRed)
                }
            }
        }
    }
}

@Composable
fun ZoomableImageViewer(model: Any, contentDescription: String) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val newScale = (scale * zoom).coerceIn(1f, 5f)
                    scale = newScale
                    offset = if (newScale > 1f) offset + pan else Offset.Zero
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = model,
            contentDescription = contentDescription,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offset.x
                    translationY = offset.y
                }
        )
    }
}

@Composable
fun ExoVideoViewer(uri: Uri) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(Media3Item.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(player) {
        onDispose {
            player.release()
        }
    }

    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = true
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0L) return "Unknown size"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    return if (mb >= 1.0) "%.1f MB".format(mb) else "%.0f KB".format(kb)
}
