package com.aklas.gallery

import android.app.Application
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.aklas.gallery.data.repository.GalleryRepository
import com.aklas.gallery.data.security.PinManager
import com.aklas.gallery.data.security.VaultCryptoManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AklasGalleryApp : Application(), DefaultLifecycleObserver, ImageLoaderFactory {
    val cryptoManager by lazy { VaultCryptoManager() }
    val pinManager by lazy { PinManager(this) }
    val repository by lazy { GalleryRepository(this, cryptoManager) }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .crossfade(true)
            .build()

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var backgroundTimestampMs: Long? = null
    private val _vaultShouldLock = MutableStateFlow(true)
    val vaultShouldLock: StateFlow<Boolean> = _vaultShouldLock.asStateFlow()

    override fun onCreate() {
        super<Application>.onCreate()
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    override fun onStop(owner: LifecycleOwner) {
        backgroundTimestampMs = System.currentTimeMillis()
        val timeout = pinManager.getAutoLockTimeout()
        if (timeout.durationMs == 0L) {
            lockVaultNow()
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        val bgTime = backgroundTimestampMs ?: return
        val timeoutMs = pinManager.getAutoLockTimeout().durationMs
        if (System.currentTimeMillis() - bgTime >= timeoutMs) {
            lockVaultNow()
        }
        backgroundTimestampMs = null
    }

    fun markVaultUnlocked() {
        _vaultShouldLock.value = false
    }

    fun lockVaultNow() {
        _vaultShouldLock.value = true
        appScope.launch {
            repository.clearAllDecryptedTempFiles()
        }
    }
}
