package com.aklas.gallery.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.aklas.gallery.AklasGalleryApp
import com.aklas.gallery.data.model.Album
import com.aklas.gallery.data.model.AutoLockTimeout
import com.aklas.gallery.data.model.GalleryStore
import com.aklas.gallery.data.model.MediaItem
import com.aklas.gallery.data.model.MediaType
import com.aklas.gallery.data.model.VaultEntry
import com.aklas.gallery.data.repository.GalleryRepository
import com.aklas.gallery.data.security.PinManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class MediaFilter { ALL, PHOTOS, VIDEOS, FAVORITES }

enum class VaultPinMode { SETUP_FIRST, SETUP_CONFIRM, LOCKED, CHANGE_VERIFY_OLD }

data class GalleryUiState(
    val store: GalleryStore = GalleryStore(),
    val activeFilter: MediaFilter = MediaFilter.ALL,
    val searchQuery: String = "",
    val isImporting: Boolean = false,
    val vaultEntries: List<VaultEntry> = emptyList(),
    val isVaultUnlocked: Boolean = false,
    val isPinConfigured: Boolean = false,
    val pinMode: VaultPinMode = VaultPinMode.SETUP_FIRST,
    val firstPinBuffer: String = "",
    val pinErrorMessage: String? = null,
    val lockoutRemainingSeconds: Int = 0,
    val autoLockTimeout: AutoLockTimeout = AutoLockTimeout.THIRTY_SECONDS,
    val activeDecryptedPreview: Pair<VaultEntry, File>? = null,
    val statusBanner: String? = null
)

class GalleryViewModel(
    private val app: AklasGalleryApp,
    private val repository: GalleryRepository,
    private val pinManager: PinManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        GalleryUiState(
            isPinConfigured = pinManager.isPinConfigured(),
            pinMode = if (pinManager.isPinConfigured()) VaultPinMode.LOCKED else VaultPinMode.SETUP_FIRST,
            autoLockTimeout = pinManager.getAutoLockTimeout()
        )
    )
    val uiState: StateFlow<GalleryUiState> = _uiState.asStateFlow()

    private var inactivityLockJob: Job? = null
    private var lockoutTickerJob: Job? = null

    init {
        viewModelScope.launch {
            val loaded = repository.loadGalleryStore()
            _uiState.update { it.copy(store = loaded) }
        }
        viewModelScope.launch {
            app.vaultShouldLock.collect { shouldLock ->
                if (shouldLock && _uiState.value.isVaultUnlocked) {
                    lockVault()
                }
            }
        }
        syncLockoutCountdown()
    }

    fun setFilter(filter: MediaFilter) {
        _uiState.update { it.copy(activeFilter = filter) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    fun importMediaFromPicker(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isImporting = true) }
            val updated = repository.importPickedUris(uris, _uiState.value.store)
            _uiState.update {
                it.copy(
                    store = updated,
                    isImporting = false,
                    statusBanner = "Imported ${uris.size} item(s) offline"
                )
            }
        }
    }

    fun toggleFavorite(itemId: String) {
        viewModelScope.launch {
            val current = _uiState.value.store
            val updatedItems = current.items.map {
                if (it.id == itemId) it.copy(isFavorite = !it.isFavorite) else it
            }
            val updatedStore = current.copy(items = updatedItems)
            repository.saveGalleryStore(updatedStore)
            _uiState.update { it.copy(store = updatedStore) }
        }
    }

    fun createAlbum(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            val current = _uiState.value.store
            val album = Album(id = UUID.randomUUID().toString(), name = trimmed)
            val updatedStore = current.copy(albums = current.albums + album)
            repository.saveGalleryStore(updatedStore)
            _uiState.update { it.copy(store = updatedStore) }
        }
    }

    fun toggleItemInAlbum(itemId: String, albumId: String) {
        viewModelScope.launch {
            val current = _uiState.value.store
            val updatedItems = current.items.map { item ->
                if (item.id != itemId) item
                else {
                    val nextAlbums = if (albumId in item.albumIds) {
                        item.albumIds - albumId
                    } else {
                        item.albumIds + albumId
                    }
                    item.copy(albumIds = nextAlbums)
                }
            }
            val updatedStore = current.copy(items = updatedItems)
            repository.saveGalleryStore(updatedStore)
            _uiState.update { it.copy(store = updatedStore) }
        }
    }

    fun removeFromGallery(itemId: String) {
        viewModelScope.launch {
            val current = _uiState.value.store
            val updatedStore = current.copy(items = current.items.filterNot { it.id == itemId })
            repository.saveGalleryStore(updatedStore)
            _uiState.update { it.copy(store = updatedStore) }
        }
    }

    fun moveGalleryItemToVault(item: MediaItem) {
        viewModelScope.launch {
            _uiState.update { it.copy(isImporting = true) }
            runCatching {
                val uri = Uri.parse(item.uriString)
                repository.importUriToVault(uri)
            }.onSuccess {
                val entries = if (_uiState.value.isVaultUnlocked) repository.loadVaultEntries() else _uiState.value.vaultEntries
                _uiState.update {
                    it.copy(
                        isImporting = false,
                        vaultEntries = entries,
                        statusBanner = "Encrypted copy stored in Secret Vault"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isImporting = false,
                        statusBanner = err.message ?: "Failed to encrypt media"
                    )
                }
            }
        }
    }

    fun importDirectToVault(uris: List<Uri>) {
        if (uris.isEmpty() || !_uiState.value.isVaultUnlocked) return
        resetInactivityTimer()
        viewModelScope.launch {
            _uiState.update { it.copy(isImporting = true) }
            var successCount = 0
            for (uri in uris) {
                runCatching { repository.importUriToVault(uri) }.onSuccess { successCount++ }
            }
            val entries = repository.loadVaultEntries()
            _uiState.update {
                it.copy(
                    isImporting = false,
                    vaultEntries = entries,
                    statusBanner = "Encrypted $successCount item(s) with AES-256-GCM"
                )
            }
        }
    }

    fun submitVaultPin(pin: String) {
        val state = _uiState.value
        when (state.pinMode) {
            VaultPinMode.SETUP_FIRST -> {
                if (pin.length !in 4..6) {
                    _uiState.update { it.copy(pinErrorMessage = "Enter a 4 to 6 digit PIN") }
                    return
                }
                _uiState.update {
                    it.copy(
                        pinMode = VaultPinMode.SETUP_CONFIRM,
                        firstPinBuffer = pin,
                        pinErrorMessage = null
                    )
                }
            }

            VaultPinMode.SETUP_CONFIRM -> {
                if (pin != state.firstPinBuffer) {
                    _uiState.update {
                        it.copy(
                            pinMode = VaultPinMode.SETUP_FIRST,
                            firstPinBuffer = "",
                            pinErrorMessage = "PINs did not match. Try again."
                        )
                    }
                    return
                }
                pinManager.setPin(pin)
                onVaultAuthenticated()
            }

            VaultPinMode.CHANGE_VERIFY_OLD -> {
                when (val result = pinManager.verifyPin(pin)) {
                    PinManager.PinVerifyResult.Success -> {
                        _uiState.update {
                            it.copy(
                                isVaultUnlocked = false,
                                pinMode = VaultPinMode.SETUP_FIRST,
                                firstPinBuffer = "",
                                pinErrorMessage = null
                            )
                        }
                    }
                    is PinManager.PinVerifyResult.Invalid -> {
                        _uiState.update {
                            it.copy(pinErrorMessage = "Incorrect PIN (${result.attemptsRemainingBeforeLockout} attempts left)")
                        }
                    }
                    is PinManager.PinVerifyResult.LockedOut -> {
                        syncLockoutCountdown()
                        _uiState.update { it.copy(pinErrorMessage = "Too many attempts. Locked temporarily.") }
                    }
                    PinManager.PinVerifyResult.NotConfigured -> {
                        _uiState.update { it.copy(pinMode = VaultPinMode.SETUP_FIRST) }
                    }
                }
            }

            VaultPinMode.LOCKED -> {
                when (val result = pinManager.verifyPin(pin)) {
                    PinManager.PinVerifyResult.Success -> onVaultAuthenticated()
                    is PinManager.PinVerifyResult.Invalid -> {
                        _uiState.update {
                            it.copy(pinErrorMessage = "Incorrect PIN (${result.attemptsRemainingBeforeLockout} left)")
                        }
                    }
                    is PinManager.PinVerifyResult.LockedOut -> {
                        syncLockoutCountdown()
                        _uiState.update { it.copy(pinErrorMessage = "Vault locked due to failed attempts") }
                    }
                    PinManager.PinVerifyResult.NotConfigured -> {
                        _uiState.update { it.copy(pinMode = VaultPinMode.SETUP_FIRST) }
                    }
                }
            }
        }
    }

    fun startChangePin() {
        _uiState.update {
            it.copy(
                isVaultUnlocked = false,
                pinMode = VaultPinMode.CHANGE_VERIFY_OLD,
                pinErrorMessage = null
            )
        }
    }

    fun setAutoLockTimeout(timeout: AutoLockTimeout) {
        pinManager.setAutoLockTimeout(timeout)
        _uiState.update { it.copy(autoLockTimeout = timeout) }
        resetInactivityTimer()
    }

    fun lockVault() {
        inactivityLockJob?.cancel()
        app.lockVaultNow()
        _uiState.update {
            it.copy(
                isVaultUnlocked = false,
                vaultEntries = emptyList(),
                activeDecryptedPreview = null,
                pinMode = if (pinManager.isPinConfigured()) VaultPinMode.LOCKED else VaultPinMode.SETUP_FIRST,
                pinErrorMessage = null
            )
        }
    }

    fun openVaultEntryPreview(entry: VaultEntry) {
        resetInactivityTimer()
        viewModelScope.launch {
            runCatching { repository.decryptVaultEntryToTempFile(entry) }
                .onSuccess { file ->
                    _uiState.update { it.copy(activeDecryptedPreview = entry to file) }
                }
                .onFailure { err ->
                    _uiState.update { it.copy(statusBanner = err.message ?: "Decryption error") }
                }
        }
    }

    fun closeVaultEntryPreview() {
        resetInactivityTimer()
        viewModelScope.launch {
            repository.clearAllDecryptedTempFiles()
            _uiState.update { it.copy(activeDecryptedPreview = null) }
        }
    }

    fun deleteVaultEntry(entry: VaultEntry) {
        resetInactivityTimer()
        viewModelScope.launch {
            val remaining = repository.deleteVaultEntry(entry)
            _uiState.update {
                it.copy(
                    vaultEntries = remaining,
                    activeDecryptedPreview = null,
                    statusBanner = "Item securely wiped from Vault"
                )
            }
        }
    }

    fun registerVaultInteraction() {
        if (_uiState.value.isVaultUnlocked) {
            resetInactivityTimer()
        }
    }

    private fun onVaultAuthenticated() {
        app.markVaultUnlocked()
        viewModelScope.launch {
            val entries = repository.loadVaultEntries()
            _uiState.update {
                it.copy(
                    isPinConfigured = true,
                    isVaultUnlocked = true,
                    pinMode = VaultPinMode.LOCKED,
                    firstPinBuffer = "",
                    pinErrorMessage = null,
                    vaultEntries = entries
                )
            }
            resetInactivityTimer()
        }
    }

    private fun resetInactivityTimer() {
        inactivityLockJob?.cancel()
        val timeoutMs = _uiState.value.autoLockTimeout.durationMs
        if (timeoutMs <= 0L) return
        inactivityLockJob = viewModelScope.launch {
            delay(timeoutMs)
            lockVault()
        }
    }

    private fun syncLockoutCountdown() {
        lockoutTickerJob?.cancel()
        val initialRemaining = pinManager.getRemainingLockoutMs()
        if (initialRemaining <= 0L) {
            _uiState.update { it.copy(lockoutRemainingSeconds = 0) }
            return
        }
        lockoutTickerJob = viewModelScope.launch {
            while (true) {
                val remMs = pinManager.getRemainingLockoutMs()
                val remSec = ((remMs + 999L) / 1000L).toInt()
                _uiState.update { it.copy(lockoutRemainingSeconds = remSec) }
                if (remSec <= 0) break
                delay(1_000L)
            }
        }
    }

    fun filteredItems(): List<MediaItem> {
        val state = _uiState.value
        return state.store.items.filter { item ->
            val matchesFilter = when (state.activeFilter) {
                MediaFilter.ALL -> true
                MediaFilter.PHOTOS -> item.type == MediaType.IMAGE
                MediaFilter.VIDEOS -> item.type == MediaType.VIDEO
                MediaFilter.FAVORITES -> item.isFavorite
            }
            val matchesQuery = state.searchQuery.isBlank() ||
                item.displayName.contains(state.searchQuery, ignoreCase = true)
            matchesFilter && matchesQuery
        }
    }

    companion object {
        fun factory(app: AklasGalleryApp): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return GalleryViewModel(app, app.repository, app.pinManager) as T
                }
            }
    }
}
