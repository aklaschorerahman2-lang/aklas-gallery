package com.aklas.gallery.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AklasDarkColorScheme = darkColorScheme(
    primary = AmberAccent,
    onPrimary = AmberOnAccent,
    secondary = ObsidianSurfaceElevated,
    onSecondary = TextPrimary,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = ObsidianBorder,
    error = DangerRed,
    onError = TextPrimary
)

@Composable
fun AklasGalleryTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AklasDarkColorScheme,
        typography = AklasTypography,
        content = content
    )
}
