package com.aklas.gallery.data.security

import android.content.Context
import android.content.SharedPreferences
import com.aklas.gallery.data.model.AutoLockTimeout
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Pure PBKDF2-HMAC-SHA256 PIN verifier and attempt throttler.
 * Separated from Android Context in [PinHasher] so JVM unit tests can test
 * hashing, verification, and constant-time equality directly.
 */
object PinHasher {
    private const val ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH_BITS = 256
    private const val SALT_BYTES = 16

    fun generateSalt(): ByteArray = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }

    fun hashPin(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_LENGTH_BITS)
        return try {
            val factory = SecretKeyFactory.getInstance(ALGORITHM)
            factory.generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun verifyPin(pin: String, salt: ByteArray, expectedHash: ByteArray): Boolean {
        val candidate = hashPin(pin, salt)
        return try {
            MessageDigest.isEqual(candidate, expectedHash)
        } finally {
            candidate.fill(0)
        }
    }
}

class PinManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isPinConfigured(): Boolean =
        prefs.contains(KEY_PIN_HASH) && prefs.contains(KEY_PIN_SALT)

    fun setPin(pin: String) {
        require(pin.length in 4..6 && pin.all { it.isDigit() }) {
            "PIN must be 4 to 6 digits"
        }
        val salt = PinHasher.generateSalt()
        val hash = PinHasher.hashPin(pin, salt)
        try {
            prefs.edit()
                .putString(KEY_PIN_SALT, Base64.getEncoder().encodeToString(salt))
                .putString(KEY_PIN_HASH, Base64.getEncoder().encodeToString(hash))
                .putInt(KEY_FAILED_ATTEMPTS, 0)
                .putLong(KEY_LOCKOUT_UNTIL_MS, 0L)
                .apply()
        } finally {
            hash.fill(0)
        }
    }

    fun getRemainingLockoutMs(nowMs: Long = System.currentTimeMillis()): Long {
        val until = prefs.getLong(KEY_LOCKOUT_UNTIL_MS, 0L)
        return (until - nowMs).coerceAtLeast(0L)
    }

    fun getFailedAttempts(): Int = prefs.getInt(KEY_FAILED_ATTEMPTS, 0)

    fun verifyPin(pin: String, nowMs: Long = System.currentTimeMillis()): PinVerifyResult {
        val lockoutRemaining = getRemainingLockoutMs(nowMs)
        if (lockoutRemaining > 0L) {
            return PinVerifyResult.LockedOut(lockoutRemaining)
        }

        val saltB64 = prefs.getString(KEY_PIN_SALT, null) ?: return PinVerifyResult.NotConfigured
        val hashB64 = prefs.getString(KEY_PIN_HASH, null) ?: return PinVerifyResult.NotConfigured

        val salt = Base64.getDecoder().decode(saltB64)
        val expectedHash = Base64.getDecoder().decode(hashB64)

        return if (PinHasher.verifyPin(pin, salt, expectedHash)) {
            prefs.edit()
                .putInt(KEY_FAILED_ATTEMPTS, 0)
                .putLong(KEY_LOCKOUT_UNTIL_MS, 0L)
                .apply()
            PinVerifyResult.Success
        } else {
            val attempts = prefs.getInt(KEY_FAILED_ATTEMPTS, 0) + 1
            val lockoutMs = computeBackoffMs(attempts)
            prefs.edit()
                .putInt(KEY_FAILED_ATTEMPTS, attempts)
                .putLong(KEY_LOCKOUT_UNTIL_MS, if (lockoutMs > 0L) nowMs + lockoutMs else 0L)
                .apply()
            if (lockoutMs > 0L) {
                PinVerifyResult.LockedOut(lockoutMs)
            } else {
                PinVerifyResult.Invalid(attemptsRemainingBeforeLockout = (5 - attempts).coerceAtLeast(0))
            }
        }
    }

    fun getAutoLockTimeout(): AutoLockTimeout {
        val savedName = prefs.getString(KEY_AUTO_LOCK_TIMEOUT, AutoLockTimeout.THIRTY_SECONDS.name)
        return AutoLockTimeout.entries.firstOrNull { it.name == savedName }
            ?: AutoLockTimeout.THIRTY_SECONDS
    }

    fun setAutoLockTimeout(timeout: AutoLockTimeout) {
        prefs.edit().putString(KEY_AUTO_LOCK_TIMEOUT, timeout.name).apply()
    }

    private fun computeBackoffMs(attempts: Int): Long = when {
        attempts < 5 -> 0L
        attempts == 5 -> 30_000L
        attempts == 6 -> 60_000L
        else -> 300_000L
    }

    sealed interface PinVerifyResult {
        data object Success : PinVerifyResult
        data object NotConfigured : PinVerifyResult
        data class Invalid(val attemptsRemainingBeforeLockout: Int) : PinVerifyResult
        data class LockedOut(val remainingMs: Long) : PinVerifyResult
    }

    companion object {
        private const val PREFS_NAME = "aklas_pin_store"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
        private const val KEY_LOCKOUT_UNTIL_MS = "lockout_until_ms"
        private const val KEY_AUTO_LOCK_TIMEOUT = "auto_lock_timeout"
    }
}
