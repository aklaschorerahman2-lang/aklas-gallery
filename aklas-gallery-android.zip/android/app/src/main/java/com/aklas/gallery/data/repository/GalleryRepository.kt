package com.aklas.gallery.data.repository

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.aklas.gallery.data.model.GalleryStore
import com.aklas.gallery.data.model.MediaItem
import com.aklas.gallery.data.model.MediaType
import com.aklas.gallery.data.model.VaultEntry
import com.aklas.gallery.data.model.VaultIndex
import com.aklas.gallery.data.security.VaultCryptoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

class GalleryRepository(
    private val context: Context,
    private val cryptoManager: VaultCryptoManager
) {
    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = false
    }

    private val galleryStoreFile = File(context.filesDir, "gallery_store.json")
    private val vaultDir = File(context.filesDir, "secret_vault").apply { mkdirs() }
    private val vaultCacheDir = File(context.cacheDir, "vault_decrypted_preview").apply { mkdirs() }
    private val vaultIndexFile = File(vaultDir, "vault_index.enc")

    suspend fun loadGalleryStore(): GalleryStore = withContext(Dispatchers.IO) {
        if (!galleryStoreFile.exists()) return@withContext GalleryStore()
        runCatching {
            json.decodeFromString<GalleryStore>(galleryStoreFile.readText())
        }.getOrDefault(GalleryStore())
    }

    suspend fun saveGalleryStore(store: GalleryStore) = withContext(Dispatchers.IO) {
        galleryStoreFile.writeText(json.encodeToString(store))
    }

    suspend fun importPickedUris(uris: List<Uri>, currentStore: GalleryStore): GalleryStore =
        withContext(Dispatchers.IO) {
            val existingUris = currentStore.items.map { it.uriString }.toHashSet()
            val added = mutableListOf<MediaItem>()

            for (uri in uris) {
                val uriStr = uri.toString()
                if (uriStr in existingUris) continue

                // Persist read permission across device reboots for Android Photo Picker URIs
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }

                val metadata = extractUriMetadata(context.contentResolver, uri)
                added.add(metadata)
                existingUris.add(uriStr)
            }

            val updated = currentStore.copy(items = added + currentStore.items)
            saveGalleryStore(updated)
            updated
        }

    suspend fun loadVaultEntries(): List<VaultEntry> = withContext(Dispatchers.IO) {
        if (!vaultIndexFile.exists()) return@withContext emptyList()
        runCatching {
            val decryptedBytes = cryptoManager.decryptBytes(vaultIndexFile.readBytes())
            val index = json.decodeFromString<VaultIndex>(decryptedBytes.decodeToString())
            decryptedBytes.fill(0)
            index.entries
        }.getOrDefault(emptyList())
    }

    private suspend fun saveVaultEntries(entries: List<VaultEntry>) = withContext(Dispatchers.IO) {
        val raw = json.encodeToString(VaultIndex(entries)).encodeToByteArray()
        val encrypted = cryptoManager.encryptBytes(raw)
        raw.fill(0)
        vaultIndexFile.writeBytes(encrypted)
    }

    suspend fun importUriToVault(uri: Uri): VaultEntry = withContext(Dispatchers.IO) {
        val meta = extractUriMetadata(context.contentResolver, uri)
        val id = UUID.randomUUID().toString()
        val encFileName = "$id.akv"
        val destFile = File(vaultDir, encFileName)

        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output ->
                cryptoManager.encryptStream(input, output)
            }
        } ?: error("Unable to open selected media stream")

        val entry = VaultEntry(
            id = id,
            originalName = meta.displayName,
            mimeType = meta.mimeType,
            type = meta.type,
            originalSizeBytes = meta.sizeBytes,
            encryptedFileName = encFileName,
            durationMs = meta.durationMs
        )

        val current = loadVaultEntries()
        saveVaultEntries(listOf(entry) + current)
        entry
    }

    suspend fun decryptVaultEntryToTempFile(entry: VaultEntry): File = withContext(Dispatchers.IO) {
        val encryptedFile = File(vaultDir, entry.encryptedFileName)
        check(encryptedFile.exists()) { "Encrypted vault file missing" }

        val extension = entry.originalName.substringAfterLast('.', missingDelimiterValue = "bin")
        val tempFile = File(vaultCacheDir, "${entry.id}.$extension")
        encryptedFile.inputStream().use { input ->
            tempFile.outputStream().use { output ->
                cryptoManager.decryptStream(input, output)
            }
        }
        tempFile
    }

    suspend fun deleteVaultEntry(entry: VaultEntry): List<VaultEntry> = withContext(Dispatchers.IO) {
        cryptoManager.secureDelete(File(vaultDir, entry.encryptedFileName))
        clearVaultPreviewCacheFor(entry.id)
        val remaining = loadVaultEntries().filterNot { it.id == entry.id }
        saveVaultEntries(remaining)
        remaining
    }

    suspend fun clearAllDecryptedTempFiles() = withContext(Dispatchers.IO) {
        vaultCacheDir.listFiles()?.forEach { cryptoManager.secureDelete(it) }
    }

    private fun clearVaultPreviewCacheFor(entryId: String) {
        vaultCacheDir.listFiles()?.filter { it.name.startsWith(entryId) }?.forEach {
            cryptoManager.secureDelete(it)
        }
    }

    private fun extractUriMetadata(resolver: ContentResolver, uri: Uri): MediaItem {
        val mimeType = resolver.getType(uri) ?: "image/jpeg"
        val type = if (mimeType.startsWith("video/")) MediaType.VIDEO else MediaType.IMAGE

        var name = "Media_${System.currentTimeMillis()}"
        var size = 0L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                    if (sizeIdx >= 0) size = cursor.getLong(sizeIdx)
                }
            }

        var durationMs = 0L
        if (type == MediaType.VIDEO) {
            val retriever = MediaMetadataRetriever()
            runCatching {
                retriever.setDataSource(context, uri)
                durationMs = retriever
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
            }
            runCatching { retriever.release() }
        }

        return MediaItem(
            id = UUID.randomUUID().toString(),
            uriString = uri.toString(),
            displayName = name,
            mimeType = mimeType,
            type = type,
            sizeBytes = size,
            durationMs = durationMs
        )
    }
}
