package com.aklas.gallery.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.Photo
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.aklas.gallery.data.model.AutoLockTimeout
import com.aklas.gallery.data.model.MediaType
import com.aklas.gallery.data.model.VaultEntry
import com.aklas.gallery.ui.theme.AmberAccent
import com.aklas.gallery.ui.theme.AmberOnAccent
import com.aklas.gallery.ui.theme.DangerRed
import com.aklas.gallery.ui.theme.ObsidianBorder
import com.aklas.gallery.ui.theme.ObsidianSurface
import com.aklas.gallery.ui.theme.ObsidianSurfaceElevated
import com.aklas.gallery.ui.theme.TextPrimary
import com.aklas.gallery.ui.theme.TextSecondary
import com.aklas.gallery.ui.viewmodel.GalleryUiState

@Composable
fun VaultScreen(
    state: GalleryUiState,
    onImportToVault: () -> Unit,
    onOpenEntry: (VaultEntry) -> Unit,
    onDeleteEntry: (VaultEntry) -> Unit,
    onLockNow: () -> Unit,
    onChangePin: () -> Unit,
    onAutoLockTimeoutSelected: (AutoLockTimeout) -> Unit,
    onInteraction: () -> Unit
) {
    var timeoutMenuExpanded by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Secret Vault", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
                Text(
                    text = "${state.vaultEntries.size} AES-256-GCM files in private storage",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
            Row {
                Box {
                    IconButton(onClick = {
                        onInteraction()
                        timeoutMenuExpanded = true
                    }) {
                        Icon(Icons.Outlined.Timer, contentDescription = "Auto-lock timer", tint = TextPrimary)
                    }
                    DropdownMenu(
                        expanded = timeoutMenuExpanded,
                        onDismissRequest = { timeoutMenuExpanded = false },
                        containerColor = ObsidianSurface
                    ) {
                        AutoLockTimeout.entries.forEach { option ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (option == state.autoLockTimeout) "• ${option.label}" else option.label,
                                        color = if (option == state.autoLockTimeout) AmberAccent else TextPrimary
                                    )
                                },
                                onClick = {
                                    onAutoLockTimeoutSelected(option)
                                    timeoutMenuExpanded = false
                                }
                            )
                        }
                    }
                }
                IconButton(onClick = onChangePin) {
                    Icon(Icons.Outlined.Key, contentDescription = "Change PIN", tint = TextPrimary)
                }
                IconButton(onClick = onLockNow) {
                    Icon(Icons.Outlined.Lock, contentDescription = "Lock Vault", tint = AmberAccent)
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Auto-lock: ${state.autoLockTimeout.label}",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Button(
                onClick = {
                    onInteraction()
                    onImportToVault()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberAccent,
                    contentColor = AmberOnAccent
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(6.dp))
                Text("Encrypt & Import")
            }
        }

        Spacer(Modifier.height(16.dp))

        if (state.vaultEntries.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No encrypted files yet. Import photos or videos directly into hardware-backed AES-256-GCM storage.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextSecondary
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(state.vaultEntries, key = { it.id }) { entry ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(ObsidianSurface)
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
                            .clickable { onOpenEntry(entry) }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(ObsidianSurfaceElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (entry.type == MediaType.VIDEO) Icons.Outlined.Movie else Icons.Outlined.Photo,
                                    contentDescription = null,
                                    tint = AmberAccent
                                )
                            }
                            Spacer(Modifier.size(12.dp))
                            Column {
                                Text(entry.originalName, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                Text(
                                    text = "${formatFileSize(entry.originalSizeBytes)} · AES-256-GCM",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                        IconButton(onClick = { onDeleteEntry(entry) }) {
                            Icon(Icons.Outlined.DeleteOutline, contentDescription = "Wipe", tint = DangerRed)
                        }
                    }
                }
            }
        }
    }
}
