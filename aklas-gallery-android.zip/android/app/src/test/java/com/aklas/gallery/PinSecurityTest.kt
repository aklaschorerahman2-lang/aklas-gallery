package com.aklas.gallery

import com.aklas.gallery.data.security.PinHasher
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PinSecurityTest {
    @Test
    fun pinHashingAndVerification_succeedsForExactMatchAndRejectsWrongPin() {
        val salt = PinHasher.generateSalt()
        val hash = PinHasher.hashPin("482910", salt)

        assertTrue(PinHasher.verifyPin("482910", salt, hash))
        assertFalse(PinHasher.verifyPin("482911", salt, hash))
        assertFalse(PinHasher.verifyPin("0000", salt, hash))
    }

    @Test
    fun distinctSalts_produceDifferentHashesForSamePin() {
        val salt1 = PinHasher.generateSalt()
        val salt2 = PinHasher.generateSalt()
        val hash1 = PinHasher.hashPin("1357", salt1)
        val hash2 = PinHasher.hashPin("1357", salt2)

        assertFalse(hash1.contentEquals(hash2))
    }
}
